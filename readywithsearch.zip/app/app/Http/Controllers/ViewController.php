<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Film;
class ViewController extends Controller
{
    public function showAll(){
        return view('home',
         [
            'films' => Film::all() ]
        );
        
    }
    public function showAllforAdmin(){
        return view('admin',
         [
            'films' => Film::all() ]
        );
        
    }
    public function add(Request $request){
        $films = new Film;
        $films->title = $request->title;
        $films->description = $request->description;
        $films->season = $request->season;
        $films->part = $request->part;
        $films->save();
        return redirect('/admin');
    }
    

    public function delete($id){
        Film::destroy($id);
        return redirect('/admin');
    }
    public function edit($id, Request $request ){
        $films=Film::find($id);
        $films->title = $request->title;
        $films->description = $request->description;
        $films->season = $request->season;
        $films->part = $request->part;
        $films->save();
        return redirect('/admin');
    }
    public function show($id){
        return view('edit',
         [
            'film' => Film::find($id) ]
        );
        
    }
    public function showId($id){
        return view('film',
         [
            'film' => Film::find($id) ]
        );
    }
    public function search(Request $request){
        return view('home', 
        [
            'films'=>Film::where('title', 'LIKE', '%' . $request->get('query') . '%')->get()]
        );
    
    }
    public function searchAdmin(Request $request){
        return view('admin', 
        [
            'films'=>Film::where('title', 'LIKE', '%' . $request->get('query') . '%')->get()]
        );
    
    }
}
