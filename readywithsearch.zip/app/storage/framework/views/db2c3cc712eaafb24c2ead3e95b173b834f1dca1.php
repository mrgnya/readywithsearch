<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="/public/css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <title>Записи</title>
    <style>
            body{
            background-color: #FDE9DA;
            font-family: sans-serif;
            color:#3D3835;
            font-size: 15pt;
            text-decoration: none;
            font-weight: 100;
            margin:0;
            padding:0;
            
        }
        a{
            color: #3D3835;
            text-decoration: none;
        }
        a:visited{
            color: #3D3835;
        }
        a:active{
            color: #3D3835;
        }
        a:hover{
            color: #3D3835;
        }
        ul{
            list-style-type:none;
            margin:0;
            
        }
        li{
            display:inline-block;
            font-size: 20pt;
            transition: 0.4s;
            padding: 5px 50px;
            color:#FDE9DA;
            
        }
        li:hover{
            background-color: #E3D1C3;
            color:#3D3835;
        }
        header{
            background-color: #7D736B;
            position: sticky;
            top: 0;
            
            padding:5px 0;
            
        }

        h1{
            font-weight: 200;
            display: inline-block;
            margin:0;
            color:#FDE9DA;
            font-size: 23pt;
            margin-left: 16%;
            width:680px;
            
            
        }
        h2{
            font-weight: 300;
            margin: 20px 10px;
        }
        .container{
            display:grid;
            grid-template-columns: 1fr 1fr 0.25fr 3fr 1fr ;
            grid-template-rows:  auto 200px ;
            grid-template-areas: 
            ". bar . main ." ;
            margin: 40px 0px;
            margin-bottom: 200px;
            
        }
        #sidebar{
            grid-area: bar;
        }
        main{
            grid-area: main;    
        }
        aside{
            background-color: rgba(238, 193, 155, 0.15);
            margin: 30px 0;
            padding: 20px 10px;
            font-size: 16pt;
            transition: 0.4s;    
        }
        aside:hover{
            background-color: #E3D1C3;
            color:#3D3835;
        }
        article{
            background-color:  rgba(238, 193, 155, 0.15);
            margin: 30px 0;
            padding: 20px 20px; 
            font-size: 16pt;   
           
            
        }
        footer{
            text-align: center;
            background-color: #7D736B;
            padding:10px 0;
            position: sticky;
            bottom: 0;
        }
        .sticky{
            position: sticky;
            top: 100px;
        }

        .reg{
            padding: 20px 0;
            margin: 10px 0;
            display:none;
            
        }
        .log{
            padding: 20px 0;
            margin: 10px 0;
            display:none;
        }
        .btn1{
            display:none;
            transition:0.4s;
        }
        .btn2{
            display:none;
            transition:0.4s;
        }
        #style1{
            display:none;
        }
        #style2{
            display:none;
        }
        label:hover{
            background-color: #E3D1C3;
            color:#3D3835;
            
        }
        label{
            transition: 0.3s;
            
            
        }
        input{
            padding: 5px 5px;
        }
        input{
            background: white;
            border:none;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
            margin: 10px 5px;
        }
        h4{
            font-size:15pt;
            font-weight:100;
        }
        .search{
            display:flex;
        }
        .searchinput{
            width:100px;
        }
        .searchbutton{
            width:50px;
        }
        
    </style>
</head>
<body>  
        <header class="search">
            <a href="/"><h1>Записи</h1></a>
            <?php if(Session::has('serverError')): ?>
                <p><?php echo e(Session::get('server')); ?></p>
                <?php endif; ?>
            <form method="POST" >
                        <input class="searchinput" type="text" name="query" placeholder="запрос">
                        <input class="searchbutton" type="submit" value="Найти">
                        <?php echo e(csrf_field()); ?>

                    </form>
        </header>
        <div class="container">
            <div id="sidebar">            
                <div class="sticky">
                <aside>
                <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                        <a href="#<?php echo e($film->id); ?>"><h4><?php echo e($film->title); ?></h4></a>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </aside>
               
               </div>
               
            </div>
            <main>
            
            <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article id="<?php echo e($film->id); ?>">
                    <a href="content/films/<?php echo e($film->id); ?>">
                    <h3><?php echo e($film->title); ?></h3>
                    <p><?php echo e($film->description); ?></p>
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </main>
        </div>
        <footer>
            Тут может быть текст
        </footer>
       
</body>
</html>