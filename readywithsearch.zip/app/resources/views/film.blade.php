<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{$film->title}}</title>

<style>
            body{
            background-color: #FDE9DA;
            font-family: sans-serif;
            color:#3D3835;
            font-size: 15pt;
            text-decoration: none;
            font-weight: 100;
            margin:0;
            padding:0;
        }
        a{
            color: #3D3835;
            text-decoration: none;
        }
        a:visited{
            color: #3D3835;
        }
        a:active{
            color: #3D3835;
        }
        a:hover{
            color: #3D3835;
        }
        ul{
            list-style-type:none;
            margin:0;
            
        }
        li{
            display:inline-block;
            font-size: 20pt;
            transition: 0.4s;
            padding: 5px 50px;
            color:#FDE9DA;
            
        }
        li:hover{
            background-color: #E3D1C3;
            color:#3D3835;
        }
        header{
            background-color: #7D736B;
            position: sticky;
            top: 0;
            padding:5px 0;
            
        }

        h1{
            font-weight: 200;
            display: inline-block;
            margin:0;
            color:#FDE9DA;
            font-size: 23pt;
            margin-left: 16%;
            
            
        }
        h2{
            font-weight: 300;
            margin: 20px 10px;
        }
        .container{
            display:grid;
            grid-template-columns: 1fr 1fr 0.25fr 3fr 1fr ;
            grid-template-rows:  auto 200px ;
            grid-template-areas: 
            ". bar . main ." ;
            margin: 40px 0px;
            margin-bottom: 200px;
        }
        #sidebar{
            grid-area: bar;
        }
        main{
            grid-area: main;    
        }
        aside{
            background-color: rgba(238, 193, 155, 0.15);
            margin: 30px 0;
            padding: 20px 10px;
            font-size: 16pt;
            transition: 0.4s;    
        }
        aside:hover{
            background-color: #E3D1C3;
            color:#3D3835;
        }
        article{
            background-color:  rgba(238, 193, 155, 0.15);
            margin: 30px 0;
            padding: 20px 20px; 
            font-size: 16pt;   
            
        }
        footer{
            text-align: center;
            background-color: #7D736B;
            padding:10px 0;
            position: sticky;
            bottom: 0;
        }
        .sticky{
            position: sticky;
            top: 135px;
        }

        .reg{
            padding: 20px 0;
            margin: 10px 0;
            display:none;
            
        }
        .log{
            padding: 20px 0;
            margin: 10px 0;
            display:none;
        }
        .btn1{
            display:none;
            transition:0.4s;
        }
        .btn2{
            display:none;
            transition:0.4s;
        }
        #style1{
            display:none;
        }
        #style2{
            display:none;
        }
        label:hover{
            background-color: #E3D1C3;
            color:#3D3835;
            padding:5px 5px;
        }
        label{
            transition: 0.3s;
            margin: 0 10px;
            
        }
        
        input{
            background: white;
            border:none;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
            margin: 10px 5px;
            padding: 5px 5px;
            
            
        }
        textarea{
            background: white;
            border:none;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
            margin: 10px 5px;
            padding: 5px 10px;
        
            
        }
        h4{
            font-weight:100;
        }
        img{
            width:300px;
            height:300px;
            border: 1px solid white;
        }
    </style>
    </head>
<body>
        <header>
                    <a href="/"><h1>Запись: {{$film->title}} </h1></a>
                    
        </header>
        <div class="container">
            <div id="sidebar">            
                <div class="sticky">
                <aside>
                    <h3>{{$film->title}}</h3>
                    <p>{{$film->description}}</p>
                   
                    </aside>
                </div>
            </div>
               <main>
                   <article>
                   <img src="/img/{{$film->part}}">
                   </article>
                  <article><h4>{{$film->season}}</h4></article>
               



               </main>
        </div>
            
   
        
            
        
    
    <footer>//</footer>
</body>
</html>